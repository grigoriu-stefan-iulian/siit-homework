function msg() {
    alert("Data Submited.\nThankyou!");
}